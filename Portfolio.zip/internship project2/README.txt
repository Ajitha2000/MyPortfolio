My Portfolio

        Showing your current work inspires confidence in your company or person. 
		If you are just entering the labor market or running a small business, 
		you do not have much recognition yet. You have to win favor in order to progress. 
		The best way to do this is to present your work so far. 
		The portfolio will be your confirmation that you do your job properly,
		 have experience and operate professionally.

Completed in projects

      TODO list
      GITHUB Profile
      Drinking water
      Image Crousel
      Password Generator
      Movie App
      Quiz App
    

JQuery

     Web developers use JavaScript every day to bring the necessary functionality to the websites they create.
	  jQuery is a special tool that provides powerful features and flexibility. 
	  jQuery is a JavaScript library that helps simplify and standardize the interaction between JavaScript code and HTML elements.
	JavaScript allows websites to be interactive and dynamic, and jQuery is a tool that helps simplify the process. 
	We will dive into what this means, how it works, and why it is so useful.