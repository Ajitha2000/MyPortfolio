function displayGreeting() {
    const nameInput = document.getElementById('name');
    const greeting = document.getElementById('greeting');

    if (nameInput.value.trim() !== '') {
        greeting.textContent = `Hello, ${nameInput.value}! Welcome to my portfolio.`;
    } else {
        greeting.textContent = 'Welcome to my portfolio.';
    }
}

function handleSubmit(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('mail').value;
    const message = document.getElementById('message').value;

    if (name.trim() === '' || email.trim() === '' || message.trim() === '') {
        alert('Please fill in all the fields.');
        return;
    }

    fetch('/submit-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, message })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);

            document.getElementById('name').value = '';
            document.getElementById('mail').value = '';
            document.getElementById('message').value = '';
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

window.addEventListener('DOMContentLoaded', function() {
    const greetingButton = document.getElementById('greeting-button');
    greetingButton.addEventListener('click', displayGreeting);

    const contactForm = document.getElementById('contact-form');
    contactForm.addEventListener('submit', handleSubmit);
});